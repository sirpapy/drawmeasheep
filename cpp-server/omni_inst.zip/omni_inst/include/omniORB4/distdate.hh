// distdate.hh -- Automatically generated file

#define OMNIORB_DIST_DATE "Mon Apr 28 17:48:32 BST 2014 dgrisby"

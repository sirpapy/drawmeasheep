#include "../include/drawing.hpp"
/** Author : Pape NDIAYE
*/
bool Drawing::operator==( const Drawing & d ) const {
	return *this == ds;
}

Drawing::~Drawing(){}